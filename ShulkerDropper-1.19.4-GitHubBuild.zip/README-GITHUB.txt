Shulker Dropper — Fabric / Minecraft 1.19.4

This repository includes a GitHub Actions workflow to build the mod remotely.

Build steps:
1. Create a GitHub repository.
2. Upload the CONTENTS of this folder to the repository's main branch (including the hidden .github folder).
3. Open the repository's Actions tab.
4. Select "Build Shulker Dropper" and press "Run workflow", or wait for the push workflow.
5. Open the successful workflow run and download the artifact named "shulker-dropper-1.19.4".
6. Extract the artifact ZIP. The mod JAR is inside.

Requirements in PojavLauncher:
- Minecraft Java 1.19.4
- Fabric Loader
- Fabric API for 1.19.4
- Put the built mod JAR in .minecraft/mods

Note: The server controls whether item-drop actions are accepted. Check the server's rules before using automation.
