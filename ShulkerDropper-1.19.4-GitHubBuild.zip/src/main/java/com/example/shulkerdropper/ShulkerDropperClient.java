package com.example.shulkerdropper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class ShulkerDropperClient implements ClientModInitializer {
    private static KeyBinding dropKey;
    private static int queuedSyncId = -1;
    private static int nextSlot = -1;

    @Override
    public void onInitializeClient() {
        dropKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shulker_dropper.drop_all",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.shulker_dropper"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(ShulkerDropperClient::onEndTick);
    }

    private static void onEndTick(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) {
            resetQueue();
            return;
        }

        while (dropKey.wasPressed()) {
            if (client.currentScreen != null
                    && client.player.currentScreenHandler instanceof ShulkerBoxScreenHandler handler) {
                queuedSyncId = handler.syncId;
                nextSlot = 0;
            }
        }

        if (nextSlot < 0) {
            return;
        }

        if (!(client.player.currentScreenHandler instanceof ShulkerBoxScreenHandler handler)
                || handler.syncId != queuedSyncId
                || client.currentScreen == null) {
            resetQueue();
            return;
        }

        // Shulker inventory occupies the first 27 slots of this screen handler.
        if (nextSlot < 27) {
            Slot slot = handler.slots.get(nextSlot);
            if (slot.hasStack()) {
                // THROW with button 1 drops the entire stack from this slot.
                client.interactionManager.clickSlot(
                        handler.syncId,
                        slot.id,
                        1,
                        SlotActionType.THROW,
                        client.player
                );
            }
            nextSlot++;
        } else {
            resetQueue();
        }
    }

    private static void resetQueue() {
        queuedSyncId = -1;
        nextSlot = -1;
    }
}
