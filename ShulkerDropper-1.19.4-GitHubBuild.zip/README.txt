Shulker Dropper — Minecraft Java 1.19.4 (Fabric)

What it does:
- Open a shulker box.
- Press G.
- It sends normal inventory THROW actions for the 27 shulker slots, one slot per client tick.
- It does not run on ordinary chests or other container screens.

Build:
1. Install JDK 17 or newer and Gradle.
2. In this project folder, run: gradle build
3. The mod JAR will be in: build/libs/

Install:
- Use Fabric Loader for Minecraft 1.19.4 in PojavLauncher.
- Put the built shulker-dropper-1.0.0.jar in .minecraft/mods.
- Fabric API for 1.19.4 must also be installed.

Important:
- This is source code, not a prebuilt JAR.
- The server decides whether each item-drop action is accepted.
- No mod can guarantee that a server will not punish automation; check GameUp's rules first.
- Test in single-player or a permitted environment before using it online.
